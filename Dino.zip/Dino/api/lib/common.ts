function toBoolean(input: number): boolean {
  if (input == 1) return true;
  if (input == 0) return false;
}

export { toBoolean };
